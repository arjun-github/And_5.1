package com.acadgild.myapplication;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Animate extends AppCompatActivity implements Animation.AnimationListener {
    TextView txt;
    Button Btn,Btn1;
    Animation anim_fadein, anim_fadeout,anim_blink;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.animate);
        txt = (TextView) findViewById(R.id.textView);

        Btn1 = (Button) findViewById(R.id.button1);
        anim_blink = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.blink);
        anim_blink.setAnimationListener(this);
        Btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt.setVisibility(View.VISIBLE);
                txt.startAnimation(anim_blink);
                anim_blink.getRepeatMode();
            }
        });


    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {


    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
